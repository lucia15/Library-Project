var keyMirror = require('react/lib/keyMirror');

// Define action constants
module.exports = keyMirror({
  BOOK_ADD: null,
  BOOK_DELETE: null,
  BOOK_EDIT: null,
  BOOK_GET: null,
  BOOKS_GET: null,
  BOOKS_SEARCH: null
});
