module.exports = {
  url: "http://localhost:9090"
};
